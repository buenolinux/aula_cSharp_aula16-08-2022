﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _02_Calculadora
{
    public partial class frmCalculadora : Form
    {
        public frmCalculadora()
        {
            InitializeComponent();
        }
        // Criando as variáveis do sistema
        double a;
        double b;
        string c;

        private void btnUm_Click(object sender, EventArgs e)
        {
            // Botão 1
            if (txbEntrada.Text == "")
            {
                txbEntrada.Text = "1";
            }
            else
            {
                txbEntrada.Text = txbEntrada.Text + "1";
            }
            btnIgual.Focus();
        }

        private void btnDois_Click(object sender, EventArgs e)
        {
            // Botão 2
            if (txbEntrada.Text == "")
            {
                txbEntrada.Text = "2";
            }
            else
            {
                txbEntrada.Text = txbEntrada.Text + "2";
            }
            btnIgual.Focus();
        }

        private void btnTres_Click(object sender, EventArgs e)
        {
            // Botão 3
            if (txbEntrada.Text == "")
            {
                txbEntrada.Text = "3";
            }
            else
            {
                txbEntrada.Text = txbEntrada.Text + "3";
            }
            btnIgual.Focus();
        }

        private void btnQuatro_Click(object sender, EventArgs e)
        {
            // Botão 4
            if (txbEntrada.Text == "")
            {
                txbEntrada.Text = "4";
            }
            else
            {
                txbEntrada.Text = txbEntrada.Text + "4";
            }
            btnIgual.Focus();
        }

        private void btnCinco_Click(object sender, EventArgs e)
        {
            // Botão 5
            if (txbEntrada.Text == "")
            {
                txbEntrada.Text = "5";
            }
            else
            {
                txbEntrada.Text = txbEntrada.Text + "5";
            }
            btnIgual.Focus();
        }

        private void btnSeis_Click(object sender, EventArgs e)
        {
            // Botão 6
            if (txbEntrada.Text == "")
            {
                txbEntrada.Text = "6";
            }
            else
            {
                txbEntrada.Text = txbEntrada.Text + "6";
            }
            btnIgual.Focus();
        }

        private void btnSete_Click(object sender, EventArgs e)
        {
            // Botão 7
            if (txbEntrada.Text == "")
            {
                txbEntrada.Text = "7";
            }
            else
            {
                txbEntrada.Text = txbEntrada.Text + "7";
            }
            btnIgual.Focus();
        }

        private void btnOito_Click(object sender, EventArgs e)
        {
            // Botão 8
            if (txbEntrada.Text == "")
            {
                txbEntrada.Text = "8";
            }
            else
            {
                txbEntrada.Text = txbEntrada.Text + "8";
            }
            btnIgual.Focus();
        }

        private void btnNove_Click(object sender, EventArgs e)
        {
            // Botão 9
            if (txbEntrada.Text == "")
            {
                txbEntrada.Text = "9";
            }
            else
            {
                txbEntrada.Text = txbEntrada.Text + "9";
            }
            btnIgual.Focus();
        }

        private void btnZero_Click(object sender, EventArgs e)
        {
            // Botão 0
            if (txbEntrada.Text == "")
            {
                txbEntrada.Text = "0";
            }
            else
            {
                txbEntrada.Text = txbEntrada.Text + "0";
            }
            btnIgual.Focus();
        }

        private void btnVirgula_Click(object sender, EventArgs e)
        {
            if (txbEntrada.Text.Contains(",")== false)
            {
                txbEntrada.Text = txbEntrada.Text + ",";
            }
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txbEntrada.Text);
            c = "/";
            //limpar a telar txbEntrada.Text ="" ou
            // atrás dos números de linhas ao clicar aparece uma bolinha vermelha 
            // o programa será executado até está linha e ao precionar a tecla f11 podemos ver o 
            // valor da linha
            txbEntrada.Clear();
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txbEntrada.Text);
            c = "*";
          
            txbEntrada.Clear();
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txbEntrada.Text);
            c = "-";

            txbEntrada.Clear();
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txbEntrada.Text);
            c = "+";

            txbEntrada.Clear();
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            a = 0;
            b = 0;
            c = "";
            txbEntrada.Clear();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            try
            {
                txbEntrada.Text = txbEntrada.Text.Substring(0, txbEntrada.TextLength - 1);
            }
            catch (Exception)
            {

                //   throw MessageBox.Show( txbEntrada.Text = " já deu";
               // throw;
               // txbEntrada.Text = " já deu";
            }
            
        }

        private void btnIgual_Click(object sender, EventArgs e)
        {
            if (txbEntrada.Text != string.Empty)// verifica se não está vazio
            {
                b = Convert.ToDouble(txbEntrada.Text);

                switch (c)
                {
                    case "/":
                        txbEntrada.Text = Convert.ToString(a / b);
                        break;
                    case "*":
                        txbEntrada.Text = Convert.ToString(a * b);
                        break;
                    case "+":
                        txbEntrada.Text = Convert.ToString(a + b);
                        break;
                    case "-":
                        txbEntrada.Text = Convert.ToString(a - b);
                        break;

                }
            }
        }

        private void frmCalculadora_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.D1 || e.KeyCode == Keys.NumPad1)
            {
                btnUm.PerformClick(); // Clique automático
            }

            if (e.KeyCode == Keys.D2 || e.KeyCode == Keys.NumPad2)
            {
                btnDois.PerformClick(); // Clique automático
            }
            if (e.KeyCode == Keys.D3 || e.KeyCode == Keys.NumPad3)
            {
                btnTres.PerformClick(); // Clique automático
            }
            if (e.KeyCode == Keys.D4 || e.KeyCode == Keys.NumPad4)
            {
                btnQuatro.PerformClick(); // Clique automático
            }
            if (e.KeyCode == Keys.D5 || e.KeyCode == Keys.NumPad5)
            {
                btnCinco.PerformClick(); // Clique automático
            }
            if (e.KeyCode == Keys.D6 || e.KeyCode == Keys.NumPad6)
            {
                btnSeis.PerformClick(); // Clique automático
            }
            if (e.KeyCode == Keys.D7 || e.KeyCode == Keys.NumPad7)
            {
                btnSete.PerformClick(); // Clique automático
            }
            if (e.KeyCode == Keys.D8 || e.KeyCode == Keys.NumPad8)
            {
                btnOito.PerformClick(); // Clique automático
            }
            if (e.KeyCode == Keys.D9 || e.KeyCode == Keys.NumPad9)
            {
                btnNove.PerformClick(); // Clique automático
            }
            if (e.KeyCode == Keys.D0 || e.KeyCode == Keys.NumPad0)
            {
                btnZero.PerformClick(); // Clique automático
            }
            if (e.KeyCode == Keys.Escape)// || e.KeyCode == Keys.NumPad1)
            {
                btnApagar.PerformClick(); // Clique automático
            }
            if (e.KeyCode == Keys.Add)
            {
                btnMais.PerformClick();
            }
            if (e.KeyCode == Keys.Subtract)
            {
                btnMenos.PerformClick();
            }
            if (e.KeyCode == Keys.Multiply)
            {
                btnMultiplicar.PerformClick();
            }
            if (e.KeyCode == Keys.Divide)
            {
                btnDividir.PerformClick();
            }
            if (e.KeyValue == 188 || e.KeyValue == 110) // virgula alpha e numpad
            {
                btnVirgula.PerformClick();
            }
            if (e.KeyValue == 8)
            {
                btnLimpar.PerformClick();
            }
        }
    }
}
