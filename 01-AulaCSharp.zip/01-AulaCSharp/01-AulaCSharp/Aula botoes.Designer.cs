﻿
namespace _01_AulaCSharp
{
    partial class frmAprendendo
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAprendendo));
            this.lblTitulo = new System.Windows.Forms.Label();
            this.grpEscolha = new System.Windows.Forms.GroupBox();
            this.chkMysql = new System.Windows.Forms.CheckBox();
            this.chkCharp = new System.Windows.Forms.CheckBox();
            this.chkSQL = new System.Windows.Forms.CheckBox();
            this.grpAprender = new System.Windows.Forms.GroupBox();
            this.rdbNao = new System.Windows.Forms.RadioButton();
            this.rdbSim = new System.Windows.Forms.RadioButton();
            this.grbCadastro = new System.Windows.Forms.GroupBox();
            this.txbSenha = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txbEmail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txbNome = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFone = new System.Windows.Forms.Label();
            this.mskFone = new System.Windows.Forms.MaskedTextBox();
            this.lblLingaguen = new System.Windows.Forms.MaskedTextBox();
            this.mskData = new System.Windows.Forms.Label();
            this.dgvTeste = new System.Windows.Forms.DataGridView();
            this.lblLing = new System.Windows.Forms.Label();
            this.cbbLinguagens = new System.Windows.Forms.ComboBox();
            this.lblLinguagens = new System.Windows.Forms.Label();
            this.tabBanco2 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.lblTxtBox = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.msklogin = new System.Windows.Forms.MaskedTextBox();
            this.toolStripSalvar = new System.Windows.Forms.ToolStripButton();
            this.toolStripAlterar = new System.Windows.Forms.ToolStripButton();
            this.toolStripExcluir = new System.Windows.Forms.ToolStripButton();
            this.toolStripCancelar = new System.Windows.Forms.ToolStripButton();
            this.toolStripLogout = new System.Windows.Forms.ToolStripButton();
            this.toolStripSair = new System.Windows.Forms.ToolStripButton();
            this.picFoto = new System.Windows.Forms.PictureBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnCuidado = new System.Windows.Forms.Button();
            this.bntAtencao = new System.Windows.Forms.Button();
            this.btnOla = new System.Windows.Forms.Button();
            this.grpEscolha.SuspendLayout();
            this.grpAprender.SuspendLayout();
            this.grbCadastro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTeste)).BeginInit();
            this.tabBanco2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFoto)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(12, 46);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(216, 31);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Aprendendo C#";
            // 
            // grpEscolha
            // 
            this.grpEscolha.Controls.Add(this.chkMysql);
            this.grpEscolha.Controls.Add(this.chkCharp);
            this.grpEscolha.Controls.Add(this.chkSQL);
            this.grpEscolha.Location = new System.Drawing.Point(182, 81);
            this.grpEscolha.Name = "grpEscolha";
            this.grpEscolha.Size = new System.Drawing.Size(79, 117);
            this.grpEscolha.TabIndex = 6;
            this.grpEscolha.TabStop = false;
            this.grpEscolha.Text = "Escolha";
            // 
            // chkMysql
            // 
            this.chkMysql.AutoSize = true;
            this.chkMysql.Location = new System.Drawing.Point(6, 65);
            this.chkMysql.Name = "chkMysql";
            this.chkMysql.Size = new System.Drawing.Size(61, 17);
            this.chkMysql.TabIndex = 2;
            this.chkMysql.Text = "MySQL";
            this.chkMysql.UseVisualStyleBackColor = true;
            this.chkMysql.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged_1);
            // 
            // chkCharp
            // 
            this.chkCharp.AutoSize = true;
            this.chkCharp.Location = new System.Drawing.Point(6, 42);
            this.chkCharp.Name = "chkCharp";
            this.chkCharp.Size = new System.Drawing.Size(40, 17);
            this.chkCharp.TabIndex = 1;
            this.chkCharp.Text = "C#";
            this.chkCharp.UseVisualStyleBackColor = true;
            this.chkCharp.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // chkSQL
            // 
            this.chkSQL.AutoSize = true;
            this.chkSQL.Location = new System.Drawing.Point(6, 19);
            this.chkSQL.Name = "chkSQL";
            this.chkSQL.Size = new System.Drawing.Size(47, 17);
            this.chkSQL.TabIndex = 0;
            this.chkSQL.Text = "SQL";
            this.chkSQL.UseVisualStyleBackColor = true;
            this.chkSQL.CheckedChanged += new System.EventHandler(this.chkSQL_CheckedChanged);
            // 
            // grpAprender
            // 
            this.grpAprender.Controls.Add(this.rdbNao);
            this.grpAprender.Controls.Add(this.rdbSim);
            this.grpAprender.Location = new System.Drawing.Point(267, 81);
            this.grpAprender.Name = "grpAprender";
            this.grpAprender.Size = new System.Drawing.Size(119, 117);
            this.grpAprender.TabIndex = 7;
            this.grpAprender.TabStop = false;
            this.grpAprender.Text = "Quer aprender C#";
            // 
            // rdbNao
            // 
            this.rdbNao.AutoSize = true;
            this.rdbNao.Location = new System.Drawing.Point(11, 70);
            this.rdbNao.Name = "rdbNao";
            this.rdbNao.Size = new System.Drawing.Size(45, 17);
            this.rdbNao.TabIndex = 1;
            this.rdbNao.TabStop = true;
            this.rdbNao.Text = "Não";
            this.rdbNao.UseVisualStyleBackColor = true;
            this.rdbNao.CheckedChanged += new System.EventHandler(this.rdbNao_CheckedChanged);
            // 
            // rdbSim
            // 
            this.rdbSim.AutoSize = true;
            this.rdbSim.Location = new System.Drawing.Point(10, 34);
            this.rdbSim.Name = "rdbSim";
            this.rdbSim.Size = new System.Drawing.Size(42, 17);
            this.rdbSim.TabIndex = 0;
            this.rdbSim.TabStop = true;
            this.rdbSim.Text = "Sim";
            this.rdbSim.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbSim.UseVisualStyleBackColor = true;
            this.rdbSim.CheckedChanged += new System.EventHandler(this.rdbSim_CheckedChanged);
            // 
            // grbCadastro
            // 
            this.grbCadastro.Controls.Add(this.lblLingaguen);
            this.grbCadastro.Controls.Add(this.mskData);
            this.grbCadastro.Controls.Add(this.mskFone);
            this.grbCadastro.Controls.Add(this.txtFone);
            this.grbCadastro.Controls.Add(this.txbSenha);
            this.grbCadastro.Controls.Add(this.label3);
            this.grbCadastro.Controls.Add(this.txbEmail);
            this.grbCadastro.Controls.Add(this.label2);
            this.grbCadastro.Controls.Add(this.txbNome);
            this.grbCadastro.Controls.Add(this.label1);
            this.grbCadastro.Location = new System.Drawing.Point(182, 204);
            this.grbCadastro.Name = "grbCadastro";
            this.grbCadastro.Size = new System.Drawing.Size(200, 305);
            this.grbCadastro.TabIndex = 8;
            this.grbCadastro.TabStop = false;
            this.grbCadastro.Text = "Cadastro";
            this.grbCadastro.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txbSenha
            // 
            this.txbSenha.Location = new System.Drawing.Point(7, 173);
            this.txbSenha.Name = "txbSenha";
            this.txbSenha.PasswordChar = '*';
            this.txbSenha.Size = new System.Drawing.Size(185, 20);
            this.txbSenha.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Senha";
            // 
            // txbEmail
            // 
            this.txbEmail.Location = new System.Drawing.Point(7, 113);
            this.txbEmail.Name = "txbEmail";
            this.txbEmail.Size = new System.Drawing.Size(185, 20);
            this.txbEmail.TabIndex = 3;
            this.txbEmail.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Email:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txbNome
            // 
            this.txbNome.Location = new System.Drawing.Point(7, 54);
            this.txbNome.Name = "txbNome";
            this.txbNome.Size = new System.Drawing.Size(187, 20);
            this.txbNome.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtFone
            // 
            this.txtFone.AutoSize = true;
            this.txtFone.Location = new System.Drawing.Point(6, 213);
            this.txtFone.Name = "txtFone";
            this.txtFone.Size = new System.Drawing.Size(34, 13);
            this.txtFone.TabIndex = 6;
            this.txtFone.Text = "Fone:";
            // 
            // mskFone
            // 
            this.mskFone.Location = new System.Drawing.Point(6, 229);
            this.mskFone.Mask = "(00)00000-0000";
            this.mskFone.Name = "mskFone";
            this.mskFone.Size = new System.Drawing.Size(186, 20);
            this.mskFone.TabIndex = 7;
            this.mskFone.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBox2_MaskInputRejected);
            // 
            // lblLingaguen
            // 
            this.lblLingaguen.Location = new System.Drawing.Point(6, 276);
            this.lblLingaguen.Mask = "00/00/0000";
            this.lblLingaguen.Name = "lblLingaguen";
            this.lblLingaguen.Size = new System.Drawing.Size(186, 20);
            this.lblLingaguen.TabIndex = 9;
            // 
            // mskData
            // 
            this.mskData.AutoSize = true;
            this.mskData.Location = new System.Drawing.Point(6, 260);
            this.mskData.Name = "mskData";
            this.mskData.Size = new System.Drawing.Size(30, 13);
            this.mskData.TabIndex = 8;
            this.mskData.Text = "Data";
            // 
            // dgvTeste
            // 
            this.dgvTeste.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTeste.Location = new System.Drawing.Point(392, 87);
            this.dgvTeste.Name = "dgvTeste";
            this.dgvTeste.Size = new System.Drawing.Size(418, 183);
            this.dgvTeste.TabIndex = 10;
            // 
            // lblLing
            // 
            this.lblLing.AutoSize = true;
            this.lblLing.Location = new System.Drawing.Point(392, 277);
            this.lblLing.Name = "lblLing";
            this.lblLing.Size = new System.Drawing.Size(61, 13);
            this.lblLing.TabIndex = 11;
            this.lblLing.Text = "linguagens:";
            // 
            // cbbLinguagens
            // 
            this.cbbLinguagens.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbLinguagens.FormattingEnabled = true;
            this.cbbLinguagens.Items.AddRange(new object[] {
            "HTML",
            "CSS",
            "JavaScript",
            "PHP",
            "C#"});
            this.cbbLinguagens.Location = new System.Drawing.Point(388, 293);
            this.cbbLinguagens.Name = "cbbLinguagens";
            this.cbbLinguagens.Size = new System.Drawing.Size(208, 21);
            this.cbbLinguagens.TabIndex = 12;
            this.cbbLinguagens.SelectedIndexChanged += new System.EventHandler(this.cbblinguagens_SelectedIndexChanged);
            // 
            // lblLinguagens
            // 
            this.lblLinguagens.Location = new System.Drawing.Point(612, 293);
            this.lblLinguagens.Name = "lblLinguagens";
            this.lblLinguagens.Size = new System.Drawing.Size(150, 20);
            this.lblLinguagens.TabIndex = 13;
            // 
            // tabBanco2
            // 
            this.tabBanco2.Controls.Add(this.tabPage1);
            this.tabBanco2.Controls.Add(this.tabPage2);
            this.tabBanco2.Font = new System.Drawing.Font("Albertus MT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabBanco2.Location = new System.Drawing.Point(388, 433);
            this.tabBanco2.Name = "tabBanco2";
            this.tabBanco2.SelectedIndex = 0;
            this.tabBanco2.Size = new System.Drawing.Size(422, 121);
            this.tabBanco2.TabIndex = 12;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(414, 95);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "SqlServer";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(414, 95);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "MySql";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Albertus MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(18, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(346, 19);
            this.label4.TabIndex = 0;
            this.label4.Text = "O Sql server é um Banco de dados da Microsoft®";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Albertus MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(16, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(356, 23);
            this.label5.TabIndex = 0;
            this.label5.Text = "O My Sql é um Banco de daos da Oracle®";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSalvar,
            this.toolStripAlterar,
            this.toolStripExcluir,
            this.toolStripCancelar,
            this.toolStripLogout,
            this.toolStripSair});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(822, 46);
            this.toolStrip1.TabIndex = 14;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // lblTxtBox
            // 
            this.lblTxtBox.AutoSize = true;
            this.lblTxtBox.Location = new System.Drawing.Point(612, 320);
            this.lblTxtBox.Name = "lblTxtBox";
            this.lblTxtBox.Size = new System.Drawing.Size(170, 117);
            this.lblTxtBox.TabIndex = 16;
            this.lblTxtBox.Text = resources.GetString("lblTxtBox.Text");
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(186, 518);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Login:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // msklogin
            // 
            this.msklogin.Location = new System.Drawing.Point(188, 534);
            this.msklogin.Mask = "LLLLLLLLLL";
            this.msklogin.Name = "msklogin";
            this.msklogin.Size = new System.Drawing.Size(186, 20);
            this.msklogin.TabIndex = 18;
            // 
            // toolStripSalvar
            // 
            this.toolStripSalvar.Image = global::_01_AulaCSharp.Properties.Resources.save_24;
            this.toolStripSalvar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSalvar.Name = "toolStripSalvar";
            this.toolStripSalvar.Size = new System.Drawing.Size(42, 43);
            this.toolStripSalvar.Text = "Salvar";
            this.toolStripSalvar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripSalvar.Click += new System.EventHandler(this.toolStripSalvar_Click);
            // 
            // toolStripAlterar
            // 
            this.toolStripAlterar.Enabled = false;
            this.toolStripAlterar.Image = global::_01_AulaCSharp.Properties.Resources.update_24;
            this.toolStripAlterar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripAlterar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAlterar.Name = "toolStripAlterar";
            this.toolStripAlterar.Size = new System.Drawing.Size(46, 43);
            this.toolStripAlterar.Text = "Alterar";
            this.toolStripAlterar.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.toolStripAlterar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripExcluir
            // 
            this.toolStripExcluir.Enabled = false;
            this.toolStripExcluir.Image = global::_01_AulaCSharp.Properties.Resources.delete_24;
            this.toolStripExcluir.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripExcluir.Name = "toolStripExcluir";
            this.toolStripExcluir.Size = new System.Drawing.Size(46, 43);
            this.toolStripExcluir.Text = "Excluir";
            this.toolStripExcluir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripCancelar
            // 
            this.toolStripCancelar.Image = global::_01_AulaCSharp.Properties.Resources.cancel_241;
            this.toolStripCancelar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripCancelar.Name = "toolStripCancelar";
            this.toolStripCancelar.Size = new System.Drawing.Size(57, 43);
            this.toolStripCancelar.Tag = "";
            this.toolStripCancelar.Text = "Cancelar";
            this.toolStripCancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripCancelar.Visible = false;
            this.toolStripCancelar.Click += new System.EventHandler(this.toolStripCancelar_Click);
            // 
            // toolStripLogout
            // 
            this.toolStripLogout.Image = global::_01_AulaCSharp.Properties.Resources.logout_24;
            this.toolStripLogout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripLogout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripLogout.Name = "toolStripLogout";
            this.toolStripLogout.Size = new System.Drawing.Size(52, 43);
            this.toolStripLogout.Text = "Logout:";
            this.toolStripLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripSair
            // 
            this.toolStripSair.Image = global::_01_AulaCSharp.Properties.Resources.exit_241;
            this.toolStripSair.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSair.Name = "toolStripSair";
            this.toolStripSair.Size = new System.Drawing.Size(30, 43);
            this.toolStripSair.Text = "Sair";
            this.toolStripSair.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripSair.Click += new System.EventHandler(this.toolStripSair_Click);
            // 
            // picFoto
            // 
            this.picFoto.Image = global::_01_AulaCSharp.Properties.Resources.csharp;
            this.picFoto.Location = new System.Drawing.Point(18, 397);
            this.picFoto.Name = "picFoto";
            this.picFoto.Size = new System.Drawing.Size(158, 153);
            this.picFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picFoto.TabIndex = 5;
            this.picFoto.TabStop = false;
            // 
            // btnSair
            // 
            this.btnSair.Image = global::_01_AulaCSharp.Properties.Resources.sair;
            this.btnSair.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSair.Location = new System.Drawing.Point(18, 319);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(158, 72);
            this.btnSair.TabIndex = 4;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnCuidado
            // 
            this.btnCuidado.Image = global::_01_AulaCSharp.Properties.Resources.cuidado;
            this.btnCuidado.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCuidado.Location = new System.Drawing.Point(18, 241);
            this.btnCuidado.Name = "btnCuidado";
            this.btnCuidado.Size = new System.Drawing.Size(158, 72);
            this.btnCuidado.TabIndex = 3;
            this.btnCuidado.Text = "Cuidado!";
            this.btnCuidado.UseVisualStyleBackColor = true;
            this.btnCuidado.Click += new System.EventHandler(this.btnCuidado_Click);
            // 
            // bntAtencao
            // 
            this.bntAtencao.Image = global::_01_AulaCSharp.Properties.Resources.atencao;
            this.bntAtencao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bntAtencao.Location = new System.Drawing.Point(18, 163);
            this.bntAtencao.Name = "bntAtencao";
            this.bntAtencao.Size = new System.Drawing.Size(158, 72);
            this.bntAtencao.TabIndex = 2;
            this.bntAtencao.Text = "Atenção ";
            this.bntAtencao.UseVisualStyleBackColor = true;
            this.bntAtencao.Click += new System.EventHandler(this.bntAtencao_Click);
            // 
            // btnOla
            // 
            this.btnOla.Image = global::_01_AulaCSharp.Properties.Resources.ola;
            this.btnOla.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOla.Location = new System.Drawing.Point(18, 85);
            this.btnOla.Name = "btnOla";
            this.btnOla.Size = new System.Drawing.Size(158, 72);
            this.btnOla.TabIndex = 1;
            this.btnOla.Text = "Olá";
            this.btnOla.UseVisualStyleBackColor = true;
            this.btnOla.Click += new System.EventHandler(this.btnOla_Click);
            // 
            // frmAprendendo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(822, 680);
            this.Controls.Add(this.msklogin);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblTxtBox);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.tabBanco2);
            this.Controls.Add(this.lblLinguagens);
            this.Controls.Add(this.cbbLinguagens);
            this.Controls.Add(this.lblLing);
            this.Controls.Add(this.dgvTeste);
            this.Controls.Add(this.grbCadastro);
            this.Controls.Add(this.grpAprender);
            this.Controls.Add(this.grpEscolha);
            this.Controls.Add(this.picFoto);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnCuidado);
            this.Controls.Add(this.bntAtencao);
            this.Controls.Add(this.btnOla);
            this.Controls.Add(this.lblTitulo);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAprendendo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aprendendo C#";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmAprendendo_FormClosing);
            this.Load += new System.EventHandler(this.frmAprendendo_Load);
            this.grpEscolha.ResumeLayout(false);
            this.grpEscolha.PerformLayout();
            this.grpAprender.ResumeLayout(false);
            this.grpAprender.PerformLayout();
            this.grbCadastro.ResumeLayout(false);
            this.grbCadastro.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTeste)).EndInit();
            this.tabBanco2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnOla;
        private System.Windows.Forms.Button bntAtencao;
        private System.Windows.Forms.Button btnCuidado;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.PictureBox picFoto;
        private System.Windows.Forms.GroupBox grpEscolha;
        private System.Windows.Forms.CheckBox chkCharp;
        private System.Windows.Forms.CheckBox chkSQL;
        private System.Windows.Forms.CheckBox chkMysql;
        private System.Windows.Forms.GroupBox grpAprender;
        private System.Windows.Forms.RadioButton rdbNao;
        private System.Windows.Forms.RadioButton rdbSim;
        private System.Windows.Forms.GroupBox grbCadastro;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txbEmail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txbNome;
        private System.Windows.Forms.TextBox txbSenha;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox lblLingaguen;
        private System.Windows.Forms.Label mskData;
        private System.Windows.Forms.MaskedTextBox mskFone;
        private System.Windows.Forms.Label txtFone;
        private System.Windows.Forms.DataGridView dgvTeste;
        private System.Windows.Forms.Label lblLing;
        private System.Windows.Forms.ComboBox cbbLinguagens;
        private System.Windows.Forms.Label lblLinguagens;
        private System.Windows.Forms.TabControl tabBanco2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripSalvar;
        private System.Windows.Forms.Label lblTxtBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.MaskedTextBox msklogin;
        private System.Windows.Forms.ToolStripButton toolStripAlterar;
        private System.Windows.Forms.ToolStripButton toolStripExcluir;
        private System.Windows.Forms.ToolStripButton toolStripCancelar;
        private System.Windows.Forms.ToolStripButton toolStripLogout;
        private System.Windows.Forms.ToolStripButton toolStripSair;
    }
}

