﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _01_AulaCSharp
{
    public partial class frmAprendendo : Form
    {
        public frmAprendendo()
        {
            InitializeComponent();
        }

        private void btnOla_Click(object sender, EventArgs e)
        {
            //Caixa de mensagem: Mensagem, título,botão e ícone.
            MessageBox.Show("Olá usuário,seja bem Vindo(a)!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
