﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _01_AulaCSharp
{
    public partial class frmAprendendo : Form
    {
        public frmAprendendo()
        {
            InitializeComponent();
        }

        private void btnOla_Click(object sender, EventArgs e)
        {
            //Caixa de mensagem: Mensagem, título,botão e ícone.
            MessageBox.Show("Olá usuário,seja bem Vindo(a)!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void bntAtencao_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Atenção!!!\nNão falte nas aulas de C#", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

        }

        private void btnCuidado_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cuidado!!!\nNão faça cocozinho no código", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            DialogResult sair = MessageBox.Show("Deseja sair do Programa?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);


            Application.Exit();

        }

        private void frmAprendendo_Load(object sender, EventArgs e)
        {
            //Adicionando itens no combobox
            cbbLinguagens.Items.Add("Java");
            cbbLinguagens.Items.Add("JQuery");
            cbbLinguagens.Items.Add("Pear");

            //Adicionando as COlunas no DataGrid
            dgvTeste.Columns.Add("codigo", "Código");
            dgvTeste.Columns.Add("nome", "Nome");
            dgvTeste.Columns.Add("preco", "Preço");
            dgvTeste.Columns.Add("data", "Data");

            //ALinhando as Colunas
            dgvTeste.Columns["codigo"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvTeste.Columns["preco"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            //Laço para preencher as linha do DataGrip
            for (int cont = 0; cont <= 100; cont++)
            {
                //Cria uma linha
                DataGridViewRow item = new DataGridViewRow();
                item.CreateCells(dgvTeste);

                //Seta o valores
                item.Cells[0].Value = cont;
                item.Cells[1].Value = "Produto " + cont;
                item.Cells[2].Value = 10.50;
                item.Cells[3].Value = DateTime.Today;

                //Adc as linhas do dataGrid
                dgvTeste.Rows.Add(item);




            }


        }

        private void frmAprendendo_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult sair = MessageBox.Show("Deseja sair do Programa?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (sair == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCharp.Checked == true)
            {
                MessageBox.Show("Você marcou o C# ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Você desmarcou o C# ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
        {
            if (chkMysql.Checked == true)
            {
                MessageBox.Show("Você marcou o MySQL ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Você desmarcou o MySQL", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void chkSQL_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSQL.Checked == true)
            {
                MessageBox.Show("Você marcou o SQL server", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Você desmarcou o SQL server", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void rdbSim_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbSim.Checked == true)

            {
                MessageBox.Show("Parabéns ,você fez uma boa escolha", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void rdbNao_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbNao.Checked == true)
            {
              
                MessageBox.Show("Vacilão a vida cobrar,parça!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void cbblinguagens_SelectedIndexChanged(object sender, EventArgs e)
        {   
            //--Acd linguagens
            lblLinguagens.Text = cbbLinguagens.Text;
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripSalvar_Click(object sender, EventArgs e)
        {   //Esconder o botão Cancelar
            //Ativar o botão Salvar
            toolStripCancelar.Visible = true;
            toolStripSalvar.Enabled = false;
        }
            //
        private void toolStripCancelar_Click(object sender, EventArgs e)
        {
            //Ativar o botão salvar
            //Esconder botão cancelar
            toolStripSalvar.Enabled = true;
            toolStripCancelar.Visible = false;
           
        }

        private void toolStripSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

